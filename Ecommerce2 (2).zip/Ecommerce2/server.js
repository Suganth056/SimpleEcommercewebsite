const express =require("express");
const mongoose=require("mongoose");
const Blog  = require("./db");

const app = express()
app.set("view engine","ejs");
app.use(express.urlencoded({extended:true}));
app.use(express.static('public'));
const dbURL="mongodb+srv://suganthb056:ss666@cluster0.9vg9rqc.mongodb.net/?retryWrites=true&w=majority";
mongoose.connect(dbURL)
.then(()=>{
    console.log("mongo connected");
    app.listen(3000);
}).catch((err)=>{
    console.log(err);
})
app.post("/Ekart",(req,res)=>{
    console.log(req.body);
    const blog =new Blog(req.body)
    blog.save().then((result)=>{
        res.redirect("/Ekart")
    }).catch((err)=>{
        console.log(err)
    })
})
app.get("/home",(req,res)=>{
    res.redirect("/");
})
app.get("/Ekart",(req,res)=>{
    res.redirect("/");
})
app.get("/",(req,res)=>{
    res.render("index");
    
})
app.get("/sign-up",(req,res)=>{
    res.render("signUP");
})
app.get("/order-now",(req,res)=>{
    res.render("ordernow");
})
app.get("/page",(req,res)=>{
    res.render("pagination");
})
// save a document to the database
/*app.get("/",(req,res)=>{
    const blog=new Blog({
        emai:"new Blog54",
        password:"About new646"
    })
    blog.save()
    .then((result)=>{
        res.send(result)
    }).catch((err)=>{
        console.log(err);
    })
})*/
/*const express=require('express');

const app=express();

app.set("view engine","ejs");

app.listen(3000,()=>{
    console.log("Connected to the Server");
})
app.get("/home",(req,res)=>{
    res.render("navbar");
})
app.get("/",(req,res)=>{
    res.render("navbar");
})
app.get("/signup",(req,res)=>{
    res.render("sUP");
})*/