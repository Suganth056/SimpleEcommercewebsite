const mongoose=require("mongoose");
const Schema=mongoose.Schema;
const blogSchema= new Schema({
    email:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }
},
{ timestamps:true }
)
//Creating model--based  on schema --is an interface used to communicate and connect with DB
const Blog = mongoose.model("Blog",blogSchema);
module.exports=Blog